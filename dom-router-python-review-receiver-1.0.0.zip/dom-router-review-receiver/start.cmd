@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" goto dependencies
where py >nul 2>nul
if errorlevel 1 goto python
py -3 -m venv .venv
if errorlevel 1 goto failed
goto dependencies
:python
python -m venv .venv
if errorlevel 1 goto failed
:dependencies
".venv\Scripts\python.exe" -c "import aiohttp; assert aiohttp.__version__ == '3.14.5'" >nul 2>nul
if not errorlevel 1 goto run
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto failed
:run
echo Open the address in the receiver.start log. Default: http://127.0.0.1:19494/
echo Public examples and synthetic data only. Press Ctrl+C to stop.
".venv\Scripts\python.exe" receiver.py %*
if errorlevel 1 goto failed
exit /b 0
:failed
echo Start failed. Install Python 3.10+ from python.org and check the error above.
pause
exit /b 1
