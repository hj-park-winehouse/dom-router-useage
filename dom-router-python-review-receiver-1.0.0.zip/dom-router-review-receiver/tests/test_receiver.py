import copy
import json
from pathlib import Path
import socket
import sqlite3
import sys
import tempfile
import time
import unittest
from uuid import uuid4

from aiohttp import ClientSession, WSMsgType, WSServerHandshakeError
from aiohttp.test_utils import TestServer

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from receiver import EVENT_PATH, EventStore, Rejected, create_app, parse_event, utc_now

EXTENSION = "chrome-extension://" + "a" * 32
HEADERS = {"Origin": EXTENSION, "Content-Type": "application/json"}


def event():
    return {"schemaVersion": 1, "eventId": str(uuid4()), "eventType": "diagnostic.observed",
            "occurredAt": utc_now(), "profile": {"id": "review-genqrcode", "revision": 1},
            "channel": "demo", "carrier": "GENERIC", "scopeId": "review-local",
            "source": {"instanceId": str(uuid4()), "tabId": 1, "frameId": 0,
                       "documentGeneration": str(uuid4()), "origin": "https://genqrcode.com"},
            "correlation": {"flowId": "observe-generated-qr", "callId": str(uuid4())},
            "payload": {"qrUrl": "https://example.com/dom-router-review", "generated": True, "imageFormat": "svg"}}


def unused_port():
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


class ServerTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.port = unused_port()
        self.origin = f"http://127.0.0.1:{self.port}"
        self.server = TestServer(create_app(self.directory.name, self.port), host="127.0.0.1", port=self.port)
        await self.server.start_server()
        self.client = ClientSession()

    async def asyncTearDown(self):
        await self.client.close()
        await self.server.close()
        self.directory.cleanup()

    async def test_http_stores_before_receipt_and_duplicate_is_idempotent(self):
        e = event()
        async with self.client.post(self.origin + EVENT_PATH, json=e, headers=HEADERS) as r:
            self.assertEqual(r.status, 200)
            receipt = await r.json()
            self.assertFalse(receipt["duplicate"])
            self.assertEqual(r.headers["Access-Control-Allow-Origin"], EXTENSION)
        # Independent DB connection proves the receipt follows commit.
        db = sqlite3.connect(Path(self.directory.name) / "events.sqlite3")
        try:
            self.assertEqual(db.execute("SELECT event_id FROM events").fetchone()[0], e["eventId"])
        finally:
            db.close()
        async with self.client.post(self.origin + EVENT_PATH, json=e, headers=HEADERS) as r:
            self.assertTrue((await r.json())["duplicate"])
        changed = copy.deepcopy(e)
        changed["payload"]["qrUrl"] += "-changed"
        async with self.client.post(self.origin + EVENT_PATH, json=changed, headers=HEADERS) as r:
            self.assertEqual(r.status, 409)
        async with self.client.get(self.origin + "/api/events") as r:
            self.assertEqual((await r.json())["count"], 1)

    async def test_ws_receipt_reconnect_and_shared_http_deduplication(self):
        e = event()
        for i in range(2):
            async with self.client.ws_connect(self.origin + EVENT_PATH, origin=EXTENSION) as ws:
                await ws.send_json(e)
                receipt = await ws.receive_json(timeout=2)
                self.assertTrue(receipt["stored"])
                self.assertEqual(receipt["duplicate"], bool(i))
        async with self.client.post(self.origin + EVENT_PATH, json=e, headers=HEADERS) as r:
            self.assertTrue((await r.json())["duplicate"])

    async def test_keyless_extension_header_and_cors_preflight(self):
        async with self.client.options(self.origin + EVENT_PATH, headers={"Origin": EXTENSION,
                "Access-Control-Request-Method": "POST", "Access-Control-Request-Headers": "content-type,x-dom-router-origin"}) as r:
            self.assertEqual(r.status, 204)
            self.assertNotEqual(r.headers["Access-Control-Allow-Origin"], "*")
        async with self.client.head(self.origin + EVENT_PATH) as r:
            self.assertEqual(r.status, 200)
        async with self.client.post(self.origin + EVENT_PATH, json=event(), headers={"X-Dom-Router-Origin": EXTENSION}) as r:
            self.assertEqual(r.status, 200)

    async def test_foreign_origins_missing_origin_and_wrong_hosts_rejected(self):
        for headers in ({"Origin": "https://attacker.invalid"}, {}, {"Origin": "null"},
                        {"Origin": "https://attacker.invalid", "X-Dom-Router-Origin": EXTENSION},
                        {"Origin": EXTENSION, "Host": "rebind.invalid"}):
            async with self.client.post(self.origin + EVENT_PATH, json=event(), headers=headers) as r:
                self.assertEqual(r.status, 403)
        with self.assertRaises(WSServerHandshakeError):
            await self.client.ws_connect(self.origin + EVENT_PATH, origin="https://attacker.invalid")

    async def test_production_authentication_links_bad_json_and_oversized_payload_rejected(self):
        variants = []
        for key, value in (("channel", "production"), ("carrier", "LG"), ("eventType", "qr.ready")):
            e = event(); e[key] = value; variants.append(e)
        e = event(); e["payload"]["qrUrl"] = "https://mis-mobileid.com/i/private-token"; variants.append(e)
        e = event(); e["payload"]["qrUrl"] = "https://["; variants.append(e)
        e = event(); e["payload"]["nested"] = {}; variants.append(e)
        for e in variants:
            async with self.client.post(self.origin + EVENT_PATH, json=e, headers=HEADERS) as r:
                self.assertEqual(r.status, 400)
        for body, status in ((b"not-json", 400), (b'{"a":1,"a":2}', 400), (b"x" * 65537, 413)):
            async with self.client.post(self.origin + EVENT_PATH, data=body, headers=HEADERS) as r:
                self.assertEqual(r.status, status)
        async with self.client.post(self.origin + EVENT_PATH, data="{}", headers={"Origin": EXTENSION}) as r:
            self.assertEqual(r.status, 415)

    async def test_ws_binary_and_invalid_events_fail_without_storage(self):
        async with self.client.ws_connect(self.origin + EVENT_PATH, origin=EXTENSION) as ws:
            await ws.send_json({"unsafe": True})
            self.assertFalse((await ws.receive_json(timeout=2))["stored"])
            msg = await ws.receive(timeout=2)
            self.assertEqual(msg.type, WSMsgType.CLOSE)
        async with self.client.ws_connect(self.origin + EVENT_PATH, origin=EXTENSION) as ws:
            await ws.send_bytes(b"binary")
            self.assertEqual((await ws.receive(timeout=2)).type, WSMsgType.CLOSE)
        async with self.client.get(self.origin + "/api/events") as r:
            self.assertEqual((await r.json())["count"], 0)

    async def test_delete_requires_same_origin_nonce(self):
        async with self.client.post(self.origin + EVENT_PATH, json=event(), headers=HEADERS) as r:
            self.assertEqual(r.status, 200)
        async with self.client.post(self.origin + "/api/clear", headers={"Origin": self.origin}) as r:
            self.assertEqual(r.status, 403)
        async with self.client.get(self.origin + "/api/session") as r:
            nonce = (await r.json())["nonce"]
        async with self.client.post(self.origin + "/api/clear", headers={"Origin": self.origin, "X-Review-Nonce": nonce}) as r:
            self.assertTrue((await r.json())["cleared"])
        async with self.client.get(self.origin + "/api/events") as r:
            self.assertEqual((await r.json())["records"], [])

    async def test_dashboard_assets_and_all_importable_profiles(self):
        async with self.client.get(self.origin + "/", headers={"Sec-Fetch-Site": "cross-site", "Sec-Fetch-Mode": "navigate"}) as r:
            self.assertEqual(r.status, 200)
        async with self.client.get(self.origin + "/api/events", headers={"Sec-Fetch-Site": "cross-site"}) as r:
            self.assertEqual(r.status, 403)
        for route in ("/", "/app.js", "/styles.css", "/health"):
            async with self.client.get(self.origin + route) as r:
                self.assertEqual(r.status, 200)
                self.assertIn("frame-ancestors 'none'", r.headers["Content-Security-Policy"])
        for kind in ("dom-ws", "dom-http", "genqrcode-ws"):
            async with self.client.get(self.origin + "/profiles/" + kind + ".profile.json") as r:
                p = await r.json()
                self.assertFalse(p["enabled"])
                self.assertEqual(p["channel"], "demo")
                if kind.startswith("dom"):
                    self.assertEqual(p["origins"], [self.origin])
        async with self.client.get(self.origin + "/profiles/../../receiver.py") as r:
            self.assertEqual(r.status, 404)


class StoreAndValidationTests(unittest.TestCase):
    def test_durable_restart_retention_count_limit_and_clear(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "test.sqlite3"
            store = EventStore(path, max_events=2)
            first = event()
            for e in (first, event(), event()):
                store.put(e, "http")
            self.assertEqual(store.count(), 2)
            store.close()
            store = EventStore(path, max_events=2)
            self.assertEqual(store.count(), 2)
            with store.db:
                store.db.execute("UPDATE events SET received_epoch=?", (time.time() - 90000,))
            self.assertEqual(store.count(), 0)
            store.put(event(), "ws"); store.clear(); self.assertEqual(store.count(), 0)
            store.close()

    def test_invalid_types_unicode_duplicates_and_dates(self):
        variants = []
        for key, value in (("schemaVersion", True), ("occurredAt", "2026-10-21"), ("eventId", "bad-id")):
            e = event(); e[key] = value; variants.append(e)
        e = event(); e["payload"]["bad"] = "\ud800"; variants.append(e)
        e = event(); e["source"]["tabId"] = True; variants.append(e)
        for e in variants:
            with self.assertRaises(Rejected):
                parse_event(json.dumps(e))
        for raw in ('{"x":NaN}', '{"x":1,"x":2}', '[]', 'null', '{"x":Infinity}'):
            with self.assertRaises(Rejected):
                parse_event(raw)


if __name__ == "__main__":
    unittest.main()
