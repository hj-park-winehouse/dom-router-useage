"""Create a reviewer handoff archive from an explicit public-file allowlist."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
FILES = ["receiver.py", "requirements.txt", "requirements-lock.txt", "start.cmd", "start.sh",
         "README-ko.txt", "README-en.txt", "THIRD-PARTY-NOTICES.txt", "VERIFICATION.json",
         "package.py", "web/index.html", "web/app.js", "web/styles.css", "tests/test_receiver.py",
         "profiles/dom-http.profile.json", "profiles/dom-ws.profile.json", "profiles/genqrcode-ws.profile.json"]
if __name__ == "__main__":
    target = ROOT.parent / "dist" / "dom-router-python-review-receiver-1.0.0.zip"
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
        for name in FILES:
            archive.write(ROOT / name, "dom-router-review-receiver/" + name)
    report = {"archive": str(target), "bytes": target.stat().st_size,
              "sha256": hashlib.sha256(target.read_bytes()).hexdigest(), "files": FILES}
    target.with_suffix(".json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
