#!/bin/sh
set -eu
cd "$(dirname "$0")"
test -x .venv/bin/python || python3 -m venv .venv
.venv/bin/python -c "import aiohttp; assert aiohttp.__version__ == '3.14.5'" 2>/dev/null || .venv/bin/python -m pip install -r requirements.txt
exec .venv/bin/python receiver.py "$@"
